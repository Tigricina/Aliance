    <section class="section section-light">
        <div class="container">
            <div class="seporator"></div>
            <h2 class="section-title">схема работы</h2>
            <!-- Начало Slider схема работы -->
            <div class="swiper steps-slider">
                <!-- Additional required wrapper -->
                <ol class="swiper-wrapper steps">
                    <!-- Slides -->
                    <li class="swiper-slide steps-item"><span class="steps-num">01</span>
                        <h3 class="steps-title">Знакомство</h3>
                        <p class="steps-text">Безусловно, сплочённость команды профессионалов позволяет оценить значение
                            форм воздействия.</p>
                        <a href="#" class="button-link">Оставить заявку</a>
                    </li>
                    <li class="swiper-slide steps-item"><span class="steps-num">02</span>
                        <h3 class="steps-title">Заключение договора</h3>
                        <p class="steps-text">Лишь интерактивные прототипы призваны к ответу.</p>
                    </li>
                    <li class="swiper-slide steps-item"><span class="steps-num">03</span>
                        <h3 class="steps-title">Производство</h3>
                        <p class="steps-text">А также стремящиеся вытеснить традиционное производство, нанотехнологии
                            функционально разнесены на независимые элементы.</p>
                    </li>
                    <li class="swiper-slide steps-item"><span class="steps-num">04</span>
                        <h3 class="steps-title">Доставка</h3>
                        <p class="steps-text">В частности, экономическая повестка сегодняшнего дня говорит о
                            возможностях приоритизации разума над эмоциями.</p>
                    </li>
                </ol>

                <!-- navigation buttons -->
                <div class="steps-buttons primary-buttons-wrapper">
                    <div class="steps-button-prev primary-button-prev">
                        <svg width="24" height="24">
                            <use href="./img/sprite.svg#prev"></use>
                        </svg>
                    </div>
                    <div class="steps-button-next primary-button-next">
                        <svg width="24" height="24">
                            <use href="./img/sprite.svg#next"></use>
                        </svg>
                    </div>
                </div>
                <!-- navigation buttons steps-buttons-->

            </div>
            <!-- окончание Slider схема работы -->

        </div>
        <!-- /.container-->
    </section>